import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:math';

void main() => runApp(BabyStepsV2());

class BabyStepsV2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
      home: PantallaPrincipal(),
    );
  }
}

class Registro {
  final String tipo, hora, observacion;
  Registro(this.tipo, this.hora, this.observacion);
}

class PantallaPrincipal extends StatefulWidget {
  @override
  _PantallaPrincipalState createState() => _PantallaPrincipalState();
}

class _PantallaPrincipalState extends State<PantallaPrincipal> {
  String nombreBebe = "tu peque"; 
  final List<Registro> misRegistros = [];
  final TextEditingController _obsController = TextEditingController();
  final TextEditingController _nombreController = TextEditingController();
  String _tipoSeleccionado = 'Toma';
  late String fraseActual;

  List<String> get frasesMotivacion => [
    "Lo estás haciendo genial, Papitoll.",
    "Pasito a pasito, DESPASITOO con $nombreBebe",
    "Tranqui, en cuanto $nombreBebe se duerma, a momi tb",
    "¡Eres una MáquinA, $nombreBebe te lo agradece!",
    "Día a día, creciendo junto a $nombreBebe.",
    "Hacemos LO MEJOR para los MEJORES."
  ];

  @override
  void initState() {
    super.initState();
    fraseActual = "¡Lo estás haciendo genial, Papitoll!";
  }

  void _cambiarNombre() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Perfil del Bebé"),
        content: TextField(controller: _nombreController, decoration: const InputDecoration(hintText: "¿Cómo se llama?")),
        actions: [TextButton(onPressed: () {
          setState(() { 
            nombreBebe = _nombreController.text.isNotEmpty ? _nombreController.text : "tu peque"; 
            fraseActual = frasesMotivacion[Random().nextInt(frasesMotivacion.length)];
          });
          Navigator.pop(context);
        }, child: const Text("Guardar"))],
      ),
    );
  }

  void _agregarRegistro() {
    setState(() {
      misRegistros.insert(0, Registro(_tipoSeleccionado, DateFormat('HH:mm').format(DateTime.now()), _obsController.text));
      _obsController.clear();
      fraseActual = frasesMotivacion[Random().nextInt(frasesMotivacion.length)];
    });
    Navigator.pop(context);
  }

  void _mostrarFormulario() {
    showModalBottomSheet(
      context: context, isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 20, right: 20, top: 20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButton<String>(
            value: _tipoSeleccionado, isExpanded: true,
            items: ['Toma', 'Sueño', 'Pañal', 'Salud'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (n) => setState(() => _tipoSeleccionado = n!),
          ),
          TextField(controller: _obsController, decoration: const InputDecoration(labelText: "Notas")),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: _agregarRegistro, child: const Text("GUARDAR")),
          const SizedBox(height: 20),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("BabySteps", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.teal)),
          actions: [IconButton(icon: const Icon(Icons.face_retouching_natural), onPressed: _cambiarNombre)],
          bottom: const TabBar(tabs: [Tab(text: "CONSEJOS"), Tab(text: "DIARIO")]),
        ),
        body: TabBarView(children: [
          Column(children: [
            _buildBanner(),
            Expanded(child: ListView(padding: const EdgeInsets.all(10), children: [
              _itemGuia("1-2 m", "Contacto y reflejos.", Colors.orange.shade50),
              _itemGuia("2-3 m", "Sonrisa social.", Colors.orange.shade50),
              _itemGuia("4 m", "Agarra objetos.", Colors.purple.shade50),
              _itemGuia("6 m", "Nuevos sabores.", Colors.purple.shade50),
              _itemGuia("8 m", "Empieza el gateo.", Colors.blue.shade50),
              _itemGuia("12 m", "Primeros pasos solo.", Colors.blue.shade50),
              _itemGuia("14 m", "Digo AGUAA.", Colors.green.shade50),
              _itemGuia("18 m", "Ya soy un MáquinA.", Colors.green.shade50),
            ])),
          ]),
          _buildDiario(),
        ]),
        floatingActionButton: FloatingActionButton(onPressed: _mostrarFormulario, child: const Icon(Icons.add)),
      ),
    );
  }

  Widget _buildBanner() {
    return Container(
      width: double.infinity, margin: const EdgeInsets.all(15), padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 5)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text("¡Hola, Familia! ❤️", style: TextStyle(color: Colors.teal, fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        Text(fraseActual, style: const TextStyle(fontStyle: FontStyle.italic)),
      ]),
    );
  }

  Widget _itemGuia(String etapa, String desc, Color color) {
    return Card(elevation: 0, color: color, child: ListTile(
      leading: const Icon(Icons.star, color: Colors.teal),
      title: Text(etapa, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(desc),
    ));
  }

  Widget _buildDiario() {
    if (misRegistros.isEmpty) return const Center(child: Text("Sin registros aún"));
    return ListView.builder(
      itemCount: misRegistros.length, padding: const EdgeInsets.all(10),
      itemBuilder: (context, index) {
        IconData ic; Color col;
        if (misRegistros[index].tipo == 'Toma') { ic = Icons.local_drink; col = Colors.orange; }
        else if (misRegistros[index].tipo == 'Sueño') { ic = Icons.nightlight_round; col = Colors.indigo; }
        else if (misRegistros[index].tipo == 'Pañal') { ic = Icons.baby_changing_station; col = Colors.brown; }
        else { ic = Icons.medical_services; col = Colors.red; }
        return Card(child: ListTile(
          leading: CircleAvatar(backgroundColor: col.withOpacity(0.1), child: Icon(ic, color: col)),
          title: Text("${misRegistros[index].tipo} - ${misRegistros[index].hora}"),
          subtitle: Text(misRegistros[index].observacion),
        ));
      },
    );
  }
}